# -*- coding: utf-8 -*-
"""
user_portfolio_simulator_numba.py  (Research-informed, robust version)
---------------------------------------------------------------------
功能（針對使用者自訂多組配置）：
- 估參收縮（Ledoit–Wolf / ridge）、平均報酬收縮
- 多種引擎：normal / t / block_bootstrap（stationary）/ ewma / regime2
- 5/25 再平衡、交易成本（--tc_bps）
- 風險/績效指標：CAGR、MDD、Ulcer、TUW、MaxDD_Dur、年化波動、Sharpe、Sortino、Omega、Calmar、CVaR_5
- 圖表：CAGR 與 |MDD| 分佈，可重疊或分開
- 共同亂數（CRN）：不同配置共享同一路徑（--crn），用於更穩定的相對比較
- 參數不確定性（外層）bootstrap（--param_bootstrap_B）
- OOS 走勢外驗證（--oos_enable）

依賴：numpy pandas matplotlib numba （可選：scikit-learn）
"""

import os, sys, math, time, argparse
from dataclasses import dataclass
from typing import List, Dict, Optional, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from concurrent.futures import ProcessPoolExecutor, as_completed
from numba import njit, prange

# ---- 基本設定 ----
os.environ.setdefault("OMP_NUM_THREADS","1")
os.environ.setdefault("MKL_NUM_THREADS","1")
plt.rcParams["font.family"] = "Noto Serif CJK JP"

class ERR:
    OK=0; FILE_READ_FAIL=1001; DATA_FORMAT_ERROR=1002; PARAM_ESTIMATION_FAIL=1101
    SIM_FAIL=1301; PLOT_FAIL=1701; OOS_FAIL=1801

def status(stage: str, code: int, msg: str = ""):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    tag = "OK" if code == 0 else f"ERR{code}"
    print(f"[{ts}] [{stage}] [{tag}] {msg}")
    sys.stdout.flush()

# ---------- 公共元件（與 Optimizer 同步）----------

@dataclass
class MarketParams:
    mu_m: np.ndarray
    Sigma_m: np.ndarray
    L_m: np.ndarray
    corr_m: np.ndarray
    vol_m: np.ndarray
    noncash_cols: List[str]
    all_cols: List[str]
    ret_m_full: pd.DataFrame
    ret_m_nc: pd.DataFrame

def detect_datetime_col(df: pd.DataFrame):
    for c in df.columns:
        p = pd.to_datetime(df[c], errors="coerce", infer_datetime_format=True)
        if p.notna().mean() > 0.9:
            return c, pd.DatetimeIndex(p)
    c = df.columns[0]
    p = pd.to_datetime(df[c], errors="coerce", infer_datetime_format=True)
    if p.notna().mean() > 0.9:
        return c, pd.DatetimeIndex(p)
    return None, None

def pick_col(df: pd.DataFrame, name_candidates: List[str]) -> Optional[str]:
    low = {c.lower(): c for c in df.columns}
    for want in name_candidates:
        for key, col in low.items():
            if want.lower() == key or want.lower() in key:
                return col
    return None

def shrink_cov_from_returns(R: np.ndarray, method: str = "auto", ridge: float = 0.10) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    T, d = R.shape
    S = np.cov(R.T, ddof=0)
    vol = np.sqrt(np.clip(np.diag(S), 1e-16, None))
    corr = S / np.outer(vol, vol)
    corr = np.clip(corr, -0.999, 0.999)
    if method == "auto":
        Sigma_shrunk = None
        try:
            from sklearn.covariance import LedoitWolf
            lw = LedoitWolf().fit(R)
            Sigma_shrunk = lw.covariance_
        except Exception:
            pass
        if Sigma_shrunk is None:
            lam = min(0.5, d / max(T, 1) * 0.1)
            D = np.diag(np.diag(S))
            Sigma_shrunk = (1 - lam) * S + lam * D
    elif method == "ridge":
        lam = float(ridge)
        D = np.diag(np.diag(S))
        Sigma_shrunk = (1 - lam) * S + lam * D
    else:
        Sigma_shrunk = S

    eps = 1e-10
    try: _ = np.linalg.cholesky(Sigma_shrunk)
    except np.linalg.LinAlgError: Sigma_shrunk = Sigma_shrunk + eps * np.eye(d)

    vol = np.sqrt(np.clip(np.diag(Sigma_shrunk), 1e-16, None))
    corr = Sigma_shrunk / np.outer(vol, vol)
    corr = np.clip(corr, -0.999, 0.999)
    return Sigma_shrunk, corr, vol

def shrink_mean(mu: np.ndarray, target: Optional[np.ndarray] = None, alpha: float = 0.0) -> np.ndarray:
    if alpha <= 0: return mu.copy()
    d = mu.shape[0]
    g = np.full(d, float(mu.mean())) if target is None else target.astype(float)
    return (1.0 - alpha) * mu + alpha * g

def load_and_estimate(csv_path: str, cash_return_monthly: float = 0.0,
                      cov_shrink: str = "auto", cov_ridge: float = 0.10,
                      mean_shrink_alpha: float = 0.0) -> MarketParams:
    df = pd.read_csv(csv_path)
    date_col, date_parsed = detect_datetime_col(df)
    if date_parsed is not None:
        prices = df.set_index(date_parsed).drop(columns=[date_col], errors="ignore")
    else:
        prices = df.copy(); prices.index = pd.RangeIndex(len(prices))

    for c in prices.columns:
        if not pd.api.types.is_numeric_dtype(prices[c]):
            prices[c] = pd.to_numeric(prices[c], errors="coerce")
    prices = prices.sort_index().dropna(how="all")

    cSPY  = pick_col(prices, ["SPY"]); cQQQ  = pick_col(prices, ["QQQ"])
    cGLD  = pick_col(prices, ["GLD"]); c0050 = pick_col(prices, ["0050.TW", "0050"])
    use = [c for c in [cSPY, cQQQ, cGLD, c0050] if c is not None]
    if len(use) == 0: raise ValueError("找不到 SPY/QQQ/GLD/0050 欄位")

    px = prices[use].copy()
    rename = {}
    if cSPY:  rename[cSPY]  = "SPY"
    if cQQQ:  rename[cQQQ]  = "QQQ"
    if cGLD:  rename[cGLD]  = "GLD"
    if c0050: rename[c0050] = "0050"
    px = px.rename(columns=rename).dropna(how="any")

    px_m = px.resample("M").last()
    ret_nc = px_m.pct_change().dropna()
    ret_full = ret_nc.copy()
    ret_full["Cash"] = cash_return_monthly

    mu = ret_nc.mean(axis=0).values.astype(np.float64)
    mu = shrink_mean(mu, target=None, alpha=mean_shrink_alpha)
    Sigma_shrunk, corr, vol = shrink_cov_from_returns(ret_nc.values, method=cov_shrink, ridge=cov_ridge)
    eps = 1e-10
    try: L = np.linalg.cholesky(Sigma_shrunk)
    except np.linalg.LinAlgError: L = np.linalg.cholesky(Sigma_shrunk + eps*np.eye(Sigma_shrunk.shape[0]))

    noncash_cols = list(ret_nc.columns); all_cols = noncash_cols + ["Cash"]
    status("LOAD", ERR.OK, f"月資料 {ret_nc.index.min().date()}~{ret_nc.index.max().date()} | 資產：{noncash_cols}")
    return MarketParams(mu_m=mu, Sigma_m=Sigma_shrunk, L_m=L, corr_m=corr, vol_m=vol,
                        noncash_cols=noncash_cols, all_cols=all_cols, ret_m_full=ret_full, ret_m_nc=ret_nc)

# ---- 引擎 ----

def simulate_monthly_returns_normal(n_sims: int, months: int, mu: np.ndarray, L: np.ndarray, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed); Z = rng.standard_normal((n_sims, months, len(mu))); return Z @ L.T + mu

def simulate_monthly_returns_t(n_sims: int, months: int, mu: np.ndarray, L: np.ndarray, df: float, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed); d = len(mu)
    Z = rng.standard_normal((n_sims, months, d))
    V = rng.chisquare(df, size=(n_sims, months)) / df
    Zs = Z / np.sqrt(V)[..., None]
    return Zs @ L.T + mu

def simulate_monthly_returns_block_bootstrap(ret_nc: np.ndarray, n_sims: int, months: int, block_len: int, p_geom: float, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed)
    T, d = ret_nc.shape
    out = np.zeros((n_sims, months, d), dtype=np.float64)
    for s in range(n_sims):
        idx = np.empty(months, dtype=np.int64)
        i = rng.integers(0, T)
        for t in range(months):
            idx[t] = i
            if rng.random() < p_geom: i = rng.integers(0, T)
            else: i = (i + 1) % T
        out[s, :, :] = ret_nc[idx, :]
    return out

def estimate_regime2_from_returns(ret_nc: np.ndarray, vol_q: float = 0.6):
    T, d = ret_nc.shape
    v = np.sqrt((ret_nc**2).mean(axis=1))
    thr = np.quantile(v, vol_q)
    z = (v > thr).astype(np.int64)
    mu1 = ret_nc[z==0].mean(axis=0); S1 = np.cov(ret_nc[z==0].T, ddof=0)
    mu2 = ret_nc[z==1].mean(axis=0); S2 = np.cov(ret_nc[z==1].T, ddof=0)
    eps = 1e-10
    try: L1 = np.linalg.cholesky(S1)
    except: L1 = np.linalg.cholesky(S1 + eps*np.eye(d))
    try: L2 = np.linalg.cholesky(S2)
    except: L2 = np.linalg.cholesky(S2 + eps*np.eye(d))
    N00=N01=N10=N11=1.0
    for t in range(T-1):
        if z[t]==0 and z[t+1]==0: N00+=1
        elif z[t]==0 and z[t+1]==1: N01+=1
        elif z[t]==1 and z[t+1]==0: N10+=1
        else: N11+=1
    P = np.array([[N00/(N00+N01), N01/(N00+N01)],
                  [N10/(N10+N11), N11/(N10+N11)]], dtype=np.float64)
    return mu1, L1, mu2, L2, P

def simulate_monthly_returns_regime2(n_sims: int, months: int, ret_nc_hist: np.ndarray, seed: int, vol_q: float=0.6):
    rng = np.random.default_rng(seed)
    mu1, L1, mu2, L2, P = estimate_regime2_from_returns(ret_nc_hist, vol_q=vol_q)
    out = np.zeros((n_sims, months, ret_nc_hist.shape[1]), dtype=np.float64)
    for s in range(n_sims):
        st = rng.integers(0,2)
        for t in range(months):
            if st==0:
                z = rng.standard_normal(L1.shape[0]); out[s,t,:] = mu1 + L1 @ z
            else:
                z = rng.standard_normal(L2.shape[0]); out[s,t,:] = mu2 + L2 @ z
            if rng.random() < P[st,1]:
                st = 1-st
    return out

def simulate_engine(engine: str, n_sims: int, months: int, mp: MarketParams,
                    seed: int, t_df: float = 5.0, block_len: int = 6, p_geom: float = None, ewma_lambda: float = 0.94, vol_q: float=0.6) -> np.ndarray:
    if engine == "normal":
        return simulate_monthly_returns_normal(n_sims, months, mp.mu_m, mp.L_m, seed)
    elif engine == "t":
        return simulate_monthly_returns_t(n_sims, months, mp.mu_m, mp.L_m, t_df, seed)
    elif engine == "block_bootstrap":
        ret_nc = mp.ret_m_full[mp.noncash_cols].values.astype(np.float64)
        p_geom = (1.0/max(block_len,1)) if (p_geom is None) else p_geom
        return simulate_monthly_returns_block_bootstrap(ret_nc, n_sims, months, block_len, p_geom, seed)
    elif engine == "ewma":
        rng = np.random.default_rng(seed)
        Lcorr = np.linalg.cholesky(mp.corr_m + 1e-12*np.eye(len(mp.mu_m)))
        out = np.empty((n_sims, months, len(mp.mu_m)), dtype=np.float64)
        for s in range(n_sims):
            sigma = mp.vol_m.copy()
            for t in range(months):
                eps = rng.standard_normal(len(mp.mu_m))
                z = Lcorr @ eps
                sigma = np.sqrt(ewma_lambda * sigma**2 + (1.0 - ewma_lambda) * (z**2))
                out[s,t,:] = mp.mu_m + sigma * z
        return out
    elif engine == "regime2":
        ret_nc = mp.ret_m_full[mp.noncash_cols].values.astype(np.float64)
        return simulate_monthly_returns_regime2(n_sims, months, ret_nc, seed, vol_q=vol_q)
    else:
        raise ValueError(f"Unknown engine: {engine}")

# ---- Numba 內核：與 Optimizer 同步 ----

@njit(parallel=True, fastmath=True, cache=True)
def twr_numba_adv(Wt_full, R_nc, idx_nc, idx_cash, abs_band, rel_band, tc_frac, rf_m, tau_m):
    n_sims, M, d_nc = R_nc.shape
    YEARS = M / 12.0
    d_total = Wt_full.shape[0]

    cagr  = np.empty(n_sims, dtype=np.float64)
    mdd   = np.empty(n_sims, dtype=np.float64)
    ulcer = np.empty(n_sims, dtype=np.float64)
    tuw   = np.empty(n_sims, dtype=np.float64)
    maxdd_dur = np.empty(n_sims, dtype=np.float64)

    sum_r = np.empty(n_sims, dtype=np.float64)
    sum_r2 = np.empty(n_sims, dtype=np.float64)
    dn_sum_sq = np.empty(n_sims, dtype=np.float64)
    dn_cnt = np.empty(n_sims, dtype=np.float64)
    pos_exc = np.empty(n_sims, dtype=np.float64)
    neg_exc = np.empty(n_sims, dtype=np.float64)

    big_mask = np.zeros(d_total, dtype=np.uint8)
    for j in range(d_total):
        if Wt_full[j] >= 0.20:
            big_mask[j] = 1

    for s in prange(n_sims):
        w_full = np.zeros(d_total, dtype=np.float64)
        for j in range(d_total):
            w_full[j] = Wt_full[j]

        nav = 1.0
        peak = 1.0
        min_dd = 0.0
        months_under = 0.0
        sum_dd_sq = 0.0
        cur_dur = 0.0
        max_dur = 0.0

        sr = 0.0; sr2 = 0.0
        dsum = 0.0; dcnt = 0.0
        pexc = 0.0; nexc = 0.0

        for t in range(M):
            r_p = 0.0
            for jnc in range(d_nc):
                j_full = idx_nc[jnc]
                r_p += w_full[j_full] * R_nc[s, t, jnc]

            nav *= (1.0 + r_p)
            if nav > peak:
                peak = nav; cur_dur = 0.0
            else:
                cur_dur += 1.0
                if cur_dur > max_dur: max_dur = cur_dur
            dd = nav / peak - 1.0
            if dd < min_dd: min_dd = dd
            if dd < 0.0:
                months_under += 1.0
                sum_dd_sq += dd * dd

            sr += r_p; sr2 += r_p * r_p
            if r_p < rf_m:
                diff = rf_m - r_p
                dsum += diff * diff
                dcnt += 1.0
            diff2 = r_p - tau_m
            if diff2 >= 0: pexc += diff2
            else: nexc += -diff2

            denom = (1.0 + r_p)
            for jnc in range(d_nc):
                j_full = idx_nc[jnc]
                w_full[j_full] = w_full[j_full] * (1.0 + R_nc[s, t, jnc]) / denom
            w_full[idx_cash] = w_full[idx_cash] / denom

            if ((t+1) % 12) == 0:
                breach = False
                for j in range(d_total):
                    if big_mask[j] == 1:
                        if abs(w_full[j] - Wt_full[j]) >= abs_band:
                            breach = True; break
                if not breach:
                    for j in range(d_total):
                        if big_mask[j] == 0:
                            lo = Wt_full[j] * (1.0 - rel_band)
                            hi = Wt_full[j] * (1.0 + rel_band)
                            val = w_full[j]
                            if (val <= lo) or (val >= hi):
                                breach = True; break
                if breach:
                    turnover = 0.0
                    for j in range(d_total):
                        turnover += abs(Wt_full[j] - w_full[j])
                    turnover *= 0.5
                    if tc_frac > 0.0:
                        nav *= (1.0 - tc_frac * turnover)
                    for j in range(d_total):
                        w_full[j] = Wt_full[j]

        cagr[s] = nav**(1.0/YEARS) - 1.0
        mdd[s]  = min_dd
        ulcer[s] = math.sqrt(sum_dd_sq / months_under) if months_under > 0.0 else 0.0
        tuw[s] = months_under / M
        maxdd_dur[s] = max_dur

        sum_r[s] = sr; sum_r2[s] = sr2
        dn_sum_sq[s] = dsum; dn_cnt[s] = dcnt
        pos_exc[s] = pexc; neg_exc[s] = nexc

    return cagr, mdd, ulcer, tuw, maxdd_dur, sum_r, sum_r2, dn_sum_sq, dn_cnt, pos_exc, neg_exc

def batch_worker(args):
    (batch_idx, W_full, months, sims_this, seed, mp_pack, engine, eng_kwargs,
     idx_nc, idx_cash, abs_band, rel_band, tc_frac, rf_m, tau_m) = args
    mu, L, corr, vol, ret_full_nc = mp_pack
    if engine == "normal":
        R_nc = simulate_monthly_returns_normal(sims_this, months, mu, L, seed).astype(np.float64)
    elif engine == "t":
        R_nc = simulate_monthly_returns_t(sims_this, months, mu, L, float(eng_kwargs.get("t_df",5.0)), seed).astype(np.float64)
    elif engine == "block_bootstrap":
        R_nc = simulate_monthly_returns_block_bootstrap(ret_full_nc, sims_this, months,
                                                        int(eng_kwargs.get("block_len",6)),
                                                        float(eng_kwargs.get("p_geom", 1.0/max(int(eng_kwargs.get("block_len",6)),1))),
                                                        seed).astype(np.float64)
    elif engine == "ewma":
        R_nc = simulate_engine("ewma", sims_this, months, 
                               type("D", (), {"mu_m":mu, "corr_m":corr, "vol_m":vol})(),
                               seed, ewma_lambda=float(eng_kwargs.get("ewma_lambda",0.94))).astype(np.float64)
    elif engine == "regime2":
        R_nc = simulate_monthly_returns_regime2(sims_this, months, ret_full_nc, seed, vol_q=float(eng_kwargs.get("vol_q",0.6))).astype(np.float64)
    else:
        raise ValueError("unknown engine")
    return (batch_idx,) + twr_numba_adv(W_full.astype(np.float64), R_nc, idx_nc, idx_cash, abs_band, rel_band, tc_frac, rf_m, tau_m)

def simulate_config_distribution(W_full: np.ndarray, mp: MarketParams, months: int, n_sims_total: int, batch_size: int,
                                 seed_base: int, abs_band: float, rel_band: float, engine: str,
                                 eng_kwargs: Dict[str, float], n_jobs: int,
                                 rf_annual: float, omega_threshold_annual: float, tc_bps: float):
    idx_nc  = np.array([mp.all_cols.index(c) for c in mp.noncash_cols], dtype=np.int64)
    idx_cash= np.int64(mp.all_cols.index("Cash"))
    n_batches = math.ceil(n_sims_total / batch_size)
    mp_pack = (mp.mu_m, mp.L_m, mp.corr_m, mp.vol_m, mp.ret_m_full[mp.noncash_cols].values.astype(np.float64))

    rf_m = (1.0 + rf_annual)**(1.0/12.0) - 1.0
    tau_m = (1.0 + omega_threshold_annual)**(1.0/12.0) - 1.0
    tc_frac = tc_bps * 1e-4

    args = []
    for b in range(n_batches):
        sims_this = batch_size if (b < n_batches-1) else (n_sims_total - batch_size*(n_batches-1))
        args.append((b, W_full, months, sims_this, seed_base + b, mp_pack, engine, eng_kwargs,
                     idx_nc, idx_cash, abs_band, rel_band, tc_frac, rf_m, tau_m))

    outs = []
    with ProcessPoolExecutor(max_workers=n_jobs) as ex:
        futs = {ex.submit(batch_worker, a): a[0] for a in args}
        total = len(futs)
        for j, fut in enumerate(as_completed(futs), 1):
            outs.append(fut.result())
            left = total - j; status("SIM", ERR.OK, f"批次 {j}/{total} 完成；剩 {left}")

    outs.sort(key=lambda x: x[0])
    cat = lambda k: np.concatenate([o[k] for o in outs])
    cagr, mdd, ulcer, tuw, maxdd_dur, sum_r, sum_r2, dn_sum_sq, dn_cnt, pos_exc, neg_exc = [cat(k) for k in range(1,12)]

    M = months
    mean_r = sum_r / M
    var_r  = np.maximum(sum_r2 / M - mean_r*mean_r, 0.0)
    vol_ann = np.sqrt(var_r) * np.sqrt(12.0)
    sharpe = np.where(vol_ann>0, (mean_r - rf_m) * np.sqrt(12.0) / np.sqrt(var_r), np.nan)
    dvar   = np.where(dn_cnt>0, dn_sum_sq / dn_cnt, 0.0)
    sortino = np.where(dvar>0, (mean_r - rf_m) * np.sqrt(12.0) / np.sqrt(dvar), np.nan)
    omega = np.where(neg_exc>0, pos_exc / neg_exc, np.inf)
    calmar = np.where(mdd<0, ( (1.0+mean_r)**12 - 1.0 ) / (-mdd), np.inf)

    extra = {"vol_ann":vol_ann, "sharpe":sharpe, "sortino":sortino, "omega":omega, "calmar":calmar, "maxdd_dur":maxdd_dur}
    return cagr, mdd, ulcer, tuw, extra

def cvar_from_distribution(x: np.ndarray, alpha: float = 0.05, lower_tail: bool = True) -> float:
    if x.size == 0: return float("nan")
    if lower_tail:
        q = np.quantile(x, alpha); return float(x[x <= q].mean())
    else:
        q = np.quantile(x, 1-alpha); return float(x[x >= q].mean())

# ---- 使用者配置 ----
def default_user_configs(all_cols: List[str]):
    # 可自行修改/擴充；缺少的資產自動補 0，最後正規化到合計=1
    cfgs = [
        {"name":"Cfg1", "SPY":0.45, "QQQ":0.22, "GLD":0.00,  "0050":0.13, "Cash":0.20},
        {"name":"Cfg2", "SPY":0.35, "QQQ":0.30, "GLD":0.075, "0050":0.15, "Cash":0.125},
    ]
    out=[]
    for cfg in cfgs:
        name = cfg.get("name", f"Cfg{len(out)+1}")
        w = np.zeros(len(all_cols), dtype=np.float64)
        for j,c in enumerate(all_cols):
            if c in cfg: w[j] = float(cfg[c])
        s = w.sum()
        if s <= 0: w[:] = 1.0/len(all_cols)
        else: w /= s
        out.append({"name": name, "weights": w})
    return out

# ---- 圖表 ----
def plot_histogram(arr_dict: Dict[str, np.ndarray], title: str, xlabel: str, out_png_prefix: str,
                   overlay: bool, save_individual: bool, bins: int = 60):
    if overlay:
        plt.figure(figsize=(9.0,5.4))
        for name, arr in arr_dict.items():
            plt.hist(arr, bins=bins, density=True, alpha=0.5, label=name)
        plt.title(title); plt.xlabel(xlabel); plt.ylabel("密度"); plt.grid(True, alpha=0.3)
        plt.legend(); plt.tight_layout(); plt.savefig(f"{out_png_prefix}_overlay.png", dpi=160); plt.close()
    if save_individual:
        for name, arr in arr_dict.items():
            plt.figure(figsize=(8.5,5.0))
            plt.hist(arr, bins=bins, density=True, alpha=0.8)
            plt.title(f"{title} - {name}"); plt.xlabel(xlabel); plt.ylabel("密度")
            plt.grid(True, alpha=0.3); plt.tight_layout(); plt.savefig(f"{out_png_prefix}_{name}.png", dpi=160); plt.close()

# ---- OOS 走勢外驗證（歷史實績）----
def twr_path_from_real_returns(W_full: np.ndarray, R_nc: np.ndarray, abs_band: float, rel_band: float, tc_frac: float) -> Dict[str, float]:
    idx_nc = np.arange(R_nc.shape[1], dtype=np.int64); idx_cash = R_nc.shape[1]
    R = R_nc.reshape(1, R_nc.shape[0], R_nc.shape[1])
    cagr, mdd, ulcer, tuw, maxdd_dur, sum_r, sum_r2, dn_sum_sq, dn_cnt, pos_exc, neg_exc = twr_numba_adv(
        Wt_full=W_full, R_nc=R, idx_nc=idx_nc, idx_cash=idx_cash,
        abs_band=abs_band, rel_band=rel_band, tc_frac=tc_frac, rf_m=0.0, tau_m=0.0
    )
    M = R_nc.shape[0]
    mean_r = sum_r[0] / M; var_r = max(sum_r2[0]/M - mean_r*mean_r, 0.0)
    vol_ann = math.sqrt(var_r) * math.sqrt(12.0)
    return {"CAGR": float(cagr[0]), "MDD": float(mdd[0]), "Ulcer": float(ulcer[0]), "TUW": float(tuw[0]),
            "MaxDD_Dur": float(maxdd_dur[0]), "Vol_ann": float(vol_ann)}

def walkforward_oos(ret_nc: pd.DataFrame, W_full: np.ndarray, train_m: int, test_m: int, step_m: int,
                    cov_shrink: str, cov_ridge: float, mean_shrink_alpha: float,
                    abs_band: float, rel_band: float, tc_bps: float) -> pd.DataFrame:
    tc_frac = tc_bps * 1e-4
    rows = []; T = len(ret_nc)
    for start in range(0, T - train_m - test_m + 1, step_m):
        train = ret_nc.iloc[start:start+train_m].values
        test  = ret_nc.iloc[start+train_m:start+train_m+test_m].values
        _ = shrink_cov_from_returns(train, method=cov_shrink, ridge=cov_ridge)  # 僅示意
        summ = twr_path_from_real_returns(W_full, test, abs_band, rel_band, tc_frac)
        summ.update({"start": str(ret_nc.index[start].date()), "end": str(ret_nc.index[start+train_m+test_m-1].date())})
        rows.append(summ)
    return pd.DataFrame(rows)

# ---- 主程式 ----
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", type=str, default="normalized_closing_prices.csv")
    ap.add_argument("--years", type=int, default=20)
    ap.add_argument("--sims", type=int, default=20000)
    ap.add_argument("--batch", type=int, default=2000)
    ap.add_argument("--seed", type=int, default=12345)
    ap.add_argument("--abs_band", type=float, default=0.05)
    ap.add_argument("--rel_band", type=float, default=0.25)
    ap.add_argument("--tc_bps", type=float, default=0.0)
    ap.add_argument("--rf_annual", type=float, default=0.0)
    ap.add_argument("--omega_thr_annual", type=float, default=0.0)
    ap.add_argument("--cash_annual", type=float, default=0.00)
    ap.add_argument("--engine", type=str, default="t", choices=["normal","t","block_bootstrap","ewma","regime2"])
    ap.add_argument("--t_df", type=float, default=5.0)
    ap.add_argument("--block_len", type=int, default=6)
    ap.add_argument("--p_geom", type=float, default=0.0)
    ap.add_argument("--ewma_lambda", type=float, default=0.94)
    ap.add_argument("--vol_q", type=float, default=0.6)
    ap.add_argument("--cov_shrink", type=str, default="auto", choices=["auto","ridge","none"])
    ap.add_argument("--cov_ridge", type=float, default=0.10)
    ap.add_argument("--mean_shrink_alpha", type=float, default=0.0)
    ap.add_argument("--overlay", type=int, default=1)
    ap.add_argument("--save_individual", type=int, default=1)
    ap.add_argument("--bins", type=int, default=60)
    ap.add_argument("--jobs", type=int, default=0)
    ap.add_argument("--crn", action="store_true")
    # 外層參數不確定性 bootstrap
    ap.add_argument("--param_bootstrap_B", type=int, default=0)
    ap.add_argument("--param_block_len", type=int, default=12)
    # OOS
    ap.add_argument("--oos_train_m", type=int, default=120)
    ap.add_argument("--oos_test_m", type=int, default=60)
    ap.add_argument("--oos_step_m", type=int, default=12)
    ap.add_argument("--oos_enable", action="store_true")
    args = ap.parse_args()

    MONTHS = args.years * 12
    n_jobs = args.jobs if args.jobs>0 else max(1,(os.cpu_count() or 1))
    cash_monthly_ret = (1.0 + args.cash_annual)**(1.0/12.0) - 1.0

    mp = load_and_estimate(args.csv, cash_return_monthly=cash_monthly_ret,
                           cov_shrink=args.cov_shrink, cov_ridge=args.cov_ridge,
                           mean_shrink_alpha=args.mean_shrink_alpha)

    user_cfgs = default_user_configs(mp.all_cols)

    eng_kwargs = {"t_df":args.t_df, "block_len":args.block_len, "p_geom": (args.p_geom if args.p_geom>0 else 1.0/max(args.block_len,1)),
                  "ewma_lambda":args.ewma_lambda, "vol_q":args.vol_q}

    results = []
    cagr_map = {}; mdd_map = {}

    # 若 crn，共用一路徑（baseline，不含外層）；否則每組各自生成
    CRN_R = None
    if args.crn:
        CRN_R = simulate_engine(args.engine, args.sims, MONTHS, mp, seed=args.seed,
                                t_df=args.t_df, block_len=args.block_len, p_geom=(args.p_geom if args.p_geom>0 else None),
                                ewma_lambda=args.ewma_lambda, vol_q=args.vol_q).astype(np.float64)

    for cfg in user_cfgs:
        name = cfg["name"]; W = cfg["weights"]; S = W.sum()
        if abs(S-1.0) > 1e-9: W = W / max(S, 1e-12)

        status("SIM", ERR.OK, f"[{name}] {args.sims} sims | engine={args.engine}")
        if args.crn and CRN_R is not None:
            idx_nc  = np.array([mp.all_cols.index(c) for c in mp.noncash_cols], dtype=np.int64)
            idx_cash= np.int64(mp.all_cols.index("Cash"))
            rf_m = (1.0 + args.rf_annual)**(1.0/12.0) - 1.0
            tau_m = (1.0 + args.omega_thr_annual)**(1.0/12.0) - 1.0
            tc_frac = args.tc_bps * 1e-4
            c,m,u,t,_, sr, sr2, dss, dc, pe, ne = twr_numba_adv(W.astype(np.float64), CRN_R, idx_nc, idx_cash,
                                                                 args.abs_band, args.rel_band, tc_frac, rf_m, tau_m)
            M = MONTHS
            mean_r = sr / M; var_r = np.maximum(sr2/M - mean_r*mean_r, 0.0)
            vol_ann = np.sqrt(var_r)*np.sqrt(12.0)
            sharpe = np.where(vol_ann>0, (mean_r-rf_m)*np.sqrt(12.0)/np.sqrt(var_r), np.nan)
            dvar   = np.where(dc>0, dss/dc, 0.0)
            sortino= np.where(dvar>0, (mean_r-rf_m)*np.sqrt(12.0)/np.sqrt(dvar), np.nan)
            omega  = np.where(ne>0, pe/ne, np.inf)
            calmar = np.where(m<0, ( (1.0+mean_r)**12 - 1.0 ) / (-m), np.inf)

            C=c; D=m
        else:
            c, m, u, t, extra = simulate_config_distribution(W, mp, MONTHS, args.sims, args.batch, args.seed,
                                                             args.abs_band, args.rel_band, args.engine, eng_kwargs, n_jobs,
                                                             args.rf_annual, args.omega_thr_annual, args.tc_bps)
            vol_ann = extra["vol_ann"]; sharpe=extra["sharpe"]; sortino=extra["sortino"]; omega=extra["omega"]; calmar=extra["calmar"]
            C=c; D=m

        cagr_map[name]  = C*100.0
        mdd_map[name]   = -D*100.0

        def P(a,q): return float(np.percentile(a,q))
        row = {
            "name": name,
            "CAGR_mean": float(np.mean(C)),  "CAGR_med": float(np.median(C)),
            "CAGR_p05":  P(C,5),             "CAGR_p95":  P(C,95),
            "MDD_mean":  float(np.mean(D)),  "MDD_med":   float(np.median(D)),
            "MDD_p05":   P(D,5),             "MDD_p95":   P(D,95),
            "Vol_ann_med": float(np.median(vol_ann)),
            "Sharpe_med":  float(np.nanmedian(sharpe)),
            "Sortino_med": float(np.nanmedian(sortino)),
            "Omega_med":   float(np.nanmedian(omega)),
            "Calmar_med":  float(np.nanmedian(calmar)),
            "CAGR_CVaR5":  cvar_from_distribution(C, 0.05, lower_tail=True),
            "MDD_CVaR5":   cvar_from_distribution(-D, 0.05, lower_tail=False)
        }
        results.append(row)

    # 圖表
    plot_histogram(cagr_map, "年化報酬分佈（CAGR）", "年化報酬 (%)",
                   "cagr", overlay=bool(args.overlay), save_individual=bool(args.save_individual), bins=args.bins)
    plot_histogram(mdd_map,  "最大回撤分佈（|MDD|）", "最大回撤幅度 (%)",
                   "mdd",  overlay=bool(args.overlay), save_individual=bool(args.save_individual), bins=args.bins)

    # 走勢外驗證（取清單第一組配置示範）
    if args.oos_enable and len(user_cfgs)>0:
        try:
            oos = walkforward_oos(mp.ret_m_nc, user_cfgs[0]["weights"], args.oos_train_m, args.oos_test_m, args.oos_step_m,
                                  args.cov_shrink, args.cov_ridge, args.mean_shrink_alpha,
                                  args.abs_band, args.rel_band, args.tc_bps)
            oos.to_csv("oos_walkforward_summary.csv", index=False)
            status("OOS", ERR.OK, "已輸出 oos_walkforward_summary.csv")
        except Exception as e:
            status("OOS", ERR.OOS_FAIL, f"走勢外驗證失敗：{e}")

    pd.DataFrame(results).to_csv("summary_results_upgraded.csv", index=False)
    status("DONE", ERR.OK, "完成，summary_results_upgraded.csv / cagr_*.png / mdd_*.png 已輸出")

if __name__ == "__main__":
    main()
