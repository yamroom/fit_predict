# -*- coding: utf-8 -*-
"""
monte_carlo_optimizer_numba_process.py  (Research-informed, robust version)
----------------------------------------------------------------------------
新增重點（相較前版）：
1) 估計強化：
   - 協方差收縮（預設 auto：優先 Ledoit–Wolf；無 sklearn 時退回對角收縮）
   - 平均報酬收縮（James–Stein 風格；--mean_shrink_alpha 控制）
2) 路徑引擎新增：
   - 't' 多變量 t 分布（厚尾、尾部相依）
   - 'block_bootstrap' 多變量移動區塊重抽樣（保留時間依賴與橫斷面相關）
   - 'ewma' RiskMetrics 風格的時變波動（波動叢聚）
   - 'regime2' 兩態馬可夫體制（高/低波動）估計與模擬
3) 參數不確定性（外層）：--param_bootstrap_B>0 時，對歷史月報酬做「平穩式（stationary）bootstrap」重抽樣，
   重新估 mu/Σ，再進一步模擬後加總；反映 μ、Σ 估計不確定性。
4) 風險/績效指標擴充（逐條路徑擷取矩）：
   - CAGR、MDD、Ulcer Index、Time-Under-Water、最大回撤持續月數（MaxDD_Duration）
   - 年化波動、Sharpe（相對 rf）、Sortino（相對 rf）、Omega 比（相對門檻 τ）、Calmar（CAGR/|MDD|）
   - 分佈級 CVaR_5（CAGR 下 5% 與 |MDD| 上 5%）
5) 交易成本模型：再平衡觸發時計入週轉成本（--tc_bps，單位 bps/交易金額）。
6) 共同亂數（CRN）：--crn 令 TopK 詳模擬共用相同隨機路徑，提升配置間比較的統計效率。
7) OOS 外部驗證（walk-forward）：--oos_* 參數可於歷史資料上做走勢外回測（不模擬），驗證規則穩健度。

依賴：numpy pandas matplotlib numba （可選：scikit-learn）
注意：為避免 pickling 問題，所有 worker 與 numba 內核皆在頂層定義。
"""

import os, sys, math, time, argparse
from dataclasses import dataclass
from typing import List, Dict, Optional, Tuple

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from concurrent.futures import ProcessPoolExecutor, as_completed
from numba import njit, prange

# ---- 基本環境設定 ----
os.environ.setdefault("OMP_NUM_THREADS","1")
os.environ.setdefault("MKL_NUM_THREADS","1")
plt.rcParams["font.family"] = "Noto Serif CJK JP"

class ERR:
    OK=0; FILE_READ_FAIL=1001; DATA_FORMAT_ERROR=1002; PARAM_ESTIMATION_FAIL=1101
    SIM_FAIL=1301; RANK_FAIL=1401; PLOT_FAIL=1701; OOS_FAIL=1801

def status(stage: str, code: int, msg: str = ""):
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    tag = "OK" if code == 0 else f"ERR{code}"
    print(f"[{ts}] [{stage}] [{tag}] {msg}")
    sys.stdout.flush()

# ---------- 資料/估參 ----------

@dataclass
class MarketParams:
    mu_m: np.ndarray            # (d_nc,)
    Sigma_m: np.ndarray         # (d_nc, d_nc)
    L_m: np.ndarray             # (d_nc, d_nc) Cholesky of shrunk covariance
    corr_m: np.ndarray          # (d_nc, d_nc)
    vol_m: np.ndarray           # (d_nc,)
    noncash_cols: List[str]
    all_cols: List[str]
    ret_m_full: pd.DataFrame    # 含 Cash 欄位（月）
    ret_m_nc: pd.DataFrame      # 僅非現金（月）

def detect_datetime_col(df: pd.DataFrame):
    for c in df.columns:
        p = pd.to_datetime(df[c], errors="coerce", infer_datetime_format=True)
        if p.notna().mean() > 0.9:
            return c, pd.DatetimeIndex(p)
    c = df.columns[0]
    p = pd.to_datetime(df[c], errors="coerce", infer_datetime_format=True)
    if p.notna().mean() > 0.9:
        return c, pd.DatetimeIndex(p)
    return None, None

def pick_col(df: pd.DataFrame, name_candidates: List[str]) -> Optional[str]:
    low = {c.lower(): c for c in df.columns}
    for want in name_candidates:
        for key, col in low.items():
            if want.lower() == key or want.lower() in key:
                return col
    return None

def shrink_cov_from_returns(R: np.ndarray, method: str = "auto", ridge: float = 0.10) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """從歷史月報酬（T×d）估計 Σ 並做收縮；回傳 (Sigma_shrunk, corr, vol)"""
    T, d = R.shape
    S = np.cov(R.T, ddof=0)
    vol = np.sqrt(np.clip(np.diag(S), 1e-16, None))
    corr = S / np.outer(vol, vol)
    corr = np.clip(corr, -0.999, 0.999)

    if method == "auto":
        Sigma_shrunk = None
        try:
            from sklearn.covariance import LedoitWolf
            lw = LedoitWolf().fit(R)  # sklearn: samples × features
            Sigma_shrunk = lw.covariance_
        except Exception:
            pass
        if Sigma_shrunk is None:
            lam = min(0.5, d / max(T, 1) * 0.1)  # 簡單啟發式
            D = np.diag(np.diag(S))
            Sigma_shrunk = (1 - lam) * S + lam * D
    elif method == "ridge":
        lam = float(ridge)
        D = np.diag(np.diag(S))
        Sigma_shrunk = (1 - lam) * S + lam * D
    else:
        Sigma_shrunk = S

    eps = 1e-10
    try:
        _ = np.linalg.cholesky(Sigma_shrunk)
    except np.linalg.LinAlgError:
        Sigma_shrunk = Sigma_shrunk + eps * np.eye(d)

    vol = np.sqrt(np.clip(np.diag(Sigma_shrunk), 1e-16, None))
    corr = Sigma_shrunk / np.outer(vol, vol)
    corr = np.clip(corr, -0.999, 0.999)
    return Sigma_shrunk, corr, vol

def shrink_mean(mu: np.ndarray, target: Optional[np.ndarray] = None, alpha: float = 0.0) -> np.ndarray:
    """mu_shrunk = (1-alpha)*mu + alpha*target；target 預設為跨資產均值"""
    if alpha <= 0: return mu.copy()
    d = mu.shape[0]
    g = np.full(d, float(mu.mean())) if target is None else target.astype(float)
    return (1.0 - alpha) * mu + alpha * g

def load_and_estimate(csv_path: str, cash_return_monthly: float = 0.0,
                      cov_shrink: str = "auto", cov_ridge: float = 0.10,
                      mean_shrink_alpha: float = 0.0) -> MarketParams:
    df = pd.read_csv(csv_path)
    date_col, date_parsed = detect_datetime_col(df)
    if date_parsed is not None:
        prices = df.set_index(date_parsed).drop(columns=[date_col], errors="ignore")
    else:
        prices = df.copy(); prices.index = pd.RangeIndex(len(prices))

    for c in prices.columns:
        if not pd.api.types.is_numeric_dtype(prices[c]):
            prices[c] = pd.to_numeric(prices[c], errors="coerce")
    prices = prices.sort_index().dropna(how="all")

    cSPY  = pick_col(prices, ["SPY"]); cQQQ  = pick_col(prices, ["QQQ"])
    cGLD  = pick_col(prices, ["GLD"]); c0050 = pick_col(prices, ["0050.TW", "0050"])
    use = [c for c in [cSPY, cQQQ, cGLD, c0050] if c is not None]
    if len(use) == 0:
        raise ValueError("找不到 SPY/QQQ/GLD/0050 欄位")

    px = prices[use].copy()
    rename = {}; 
    if cSPY:  rename[cSPY]  = "SPY"
    if cQQQ:  rename[cQQQ]  = "QQQ"
    if cGLD:  rename[cGLD]  = "GLD"
    if c0050: rename[c0050] = "0050"
    px = px.rename(columns=rename).dropna(how="any")

    px_m = px.resample("M").last()
    ret_nc = px_m.pct_change().dropna()
    ret_full = ret_nc.copy()
    ret_full["Cash"] = cash_return_monthly

    mu = ret_nc.mean(axis=0).values.astype(np.float64)
    mu = shrink_mean(mu, target=None, alpha=mean_shrink_alpha)
    Sigma_shrunk, corr, vol = shrink_cov_from_returns(ret_nc.values, method=cov_shrink, ridge=cov_ridge)

    eps = 1e-10
    try:
        L = np.linalg.cholesky(Sigma_shrunk)
    except np.linalg.LinAlgError:
        L = np.linalg.cholesky(Sigma_shrunk + eps*np.eye(Sigma_shrunk.shape[0]))

    noncash_cols = list(ret_nc.columns)
    all_cols = noncash_cols + ["Cash"]
    status("LOAD", ERR.OK, f"月資料 {ret_nc.index.min().date()}~{ret_nc.index.max().date()} | 資產：{noncash_cols}")
    return MarketParams(mu_m=mu, Sigma_m=Sigma_shrunk, L_m=L, corr_m=corr, vol_m=vol,
                        noncash_cols=noncash_cols, all_cols=all_cols, ret_m_full=ret_full, ret_m_nc=ret_nc)

# ---------- 路徑引擎 ----------

def simulate_monthly_returns_normal(n_sims: int, months: int, mu: np.ndarray, L: np.ndarray, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed); Z = rng.standard_normal((n_sims, months, len(mu))); return Z @ L.T + mu

def simulate_monthly_returns_t(n_sims: int, months: int, mu: np.ndarray, L: np.ndarray, df: float, seed: int) -> np.ndarray:
    rng = np.random.default_rng(seed); d = len(mu)
    Z = rng.standard_normal((n_sims, months, d))
    V = rng.chisquare(df, size=(n_sims, months)) / df
    Zs = Z / np.sqrt(V)[..., None]
    return Zs @ L.T + mu

def simulate_monthly_returns_block_bootstrap(ret_nc: np.ndarray, n_sims: int, months: int, block_len: int, p_geom: float, seed: int) -> np.ndarray:
    """
    平穩式 bootstrap：以幾何分佈長度抽塊（Politis & Romano 1994 的簡化版本）
    p_geom = 1/L，L 為期望區塊長
    """
    rng = np.random.default_rng(seed)
    T, d = ret_nc.shape
    out = np.zeros((n_sims, months, d), dtype=np.float64)
    for s in range(n_sims):
        idx = np.empty(months, dtype=np.int64)
        i = rng.integers(0, T)
        for t in range(months):
            idx[t] = i
            if rng.random() < p_geom:
                i = rng.integers(0, T)
            else:
                i = (i + 1) % T
        out[s, :, :] = ret_nc[idx, :]
    return out

def estimate_regime2_from_returns(ret_nc: np.ndarray, vol_q: float = 0.6) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    以跨資產的月度平方均根作為當期波動 proxy，依分位數切兩體制；估 mu/Σ 與轉移機率。
    回傳：mu1, L1, mu2, L2, P (2x2)
    """
    T, d = ret_nc.shape
    v = np.sqrt((ret_nc**2).mean(axis=1))
    thr = np.quantile(v, vol_q)
    z = (v > thr).astype(np.int64)  # 0:低波, 1:高波
    mu1 = ret_nc[z==0].mean(axis=0); S1 = np.cov(ret_nc[z==0].T, ddof=0)
    mu2 = ret_nc[z==1].mean(axis=0); S2 = np.cov(ret_nc[z==1].T, ddof=0)
    eps = 1e-10
    try: L1 = np.linalg.cholesky(S1)
    except: L1 = np.linalg.cholesky(S1 + eps*np.eye(d))
    try: L2 = np.linalg.cholesky(S2)
    except: L2 = np.linalg.cholesky(S2 + eps*np.eye(d))
    # 估轉移機率
    N00=N01=N10=N11=1.0  # 加 1 做平滑
    for t in range(T-1):
        if z[t]==0 and z[t+1]==0: N00+=1
        elif z[t]==0 and z[t+1]==1: N01+=1
        elif z[t]==1 and z[t+1]==0: N10+=1
        else: N11+=1
    P = np.array([[N00/(N00+N01), N01/(N00+N01)],
                  [N10/(N10+N11), N11/(N10+N11)]], dtype=np.float64)
    return mu1, L1, mu2, L2, P

def simulate_monthly_returns_regime2(n_sims: int, months: int, ret_nc_hist: np.ndarray, seed: int, vol_q: float=0.6) -> np.ndarray:
    rng = np.random.default_rng(seed)
    mu1, L1, mu2, L2, P = estimate_regime2_from_returns(ret_nc_hist, vol_q=vol_q)
    out = np.zeros((n_sims, months, ret_nc_hist.shape[1]), dtype=np.float64)
    for s in range(n_sims):
        st = rng.integers(0,2)
        for t in range(months):
            if st==0:
                z = rng.standard_normal(L1.shape[0]); out[s,t,:] = mu1 + L1 @ z
            else:
                z = rng.standard_normal(L2.shape[0]); out[s,t,:] = mu2 + L2 @ z
            # 轉移
            if rng.random() < P[st,1]:
                st = 1-st
    return out

def simulate_engine(engine: str, n_sims: int, months: int, mp: MarketParams,
                    seed: int, t_df: float = 5.0, block_len: int = 6, p_geom: float = None, ewma_lambda: float = 0.94, vol_q: float=0.6) -> np.ndarray:
    if engine == "normal":
        return simulate_monthly_returns_normal(n_sims, months, mp.mu_m, mp.L_m, seed)
    elif engine == "t":
        return simulate_monthly_returns_t(n_sims, months, mp.mu_m, mp.L_m, t_df, seed)
    elif engine == "block_bootstrap":
        ret_nc = mp.ret_m_full[mp.noncash_cols].values.astype(np.float64)
        p_geom = (1.0/max(block_len,1)) if (p_geom is None) else p_geom
        return simulate_monthly_returns_block_bootstrap(ret_nc, n_sims, months, block_len, p_geom, seed)
    elif engine == "ewma":
        # RiskMetrics：sigma_t^2 = λ sigma_{t-1}^2 + (1-λ) z_t^2；相關固定
        rng = np.random.default_rng(seed)
        Lcorr = np.linalg.cholesky(mp.corr_m + 1e-12*np.eye(len(mp.mu_m)))
        out = np.empty((n_sims, months, len(mp.mu_m)), dtype=np.float64)
        for s in range(n_sims):
            sigma = mp.vol_m.copy()
            for t in range(months):
                eps = rng.standard_normal(len(mp.mu_m))
                z = Lcorr @ eps
                sigma = np.sqrt(ewma_lambda * sigma**2 + (1.0 - ewma_lambda) * (z**2))
                out[s,t,:] = mp.mu_m + sigma * z
        return out
    elif engine == "regime2":
        ret_nc = mp.ret_m_full[mp.noncash_cols].values.astype(np.float64)
        return simulate_monthly_returns_regime2(n_sims, months, ret_nc, seed, vol_q=vol_q)
    else:
        raise ValueError(f"Unknown engine: {engine}")

# ---------- Numba 內核：帶成本的 TWR + 5/25 再平衡 + 指標累積 ----------

@njit(parallel=True, fastmath=True, cache=True)
def twr_numba_adv(Wt_full, R_nc, idx_nc, idx_cash, abs_band, rel_band, tc_frac, rf_m, tau_m):
    """
    參數：
      Wt_full: (d_total,) 目標權重（含 Cash）
      R_nc:    (n_sims, M, d_nc) 非現金月報酬
      idx_nc:  (d_nc,) 非現金對應至 full 的索引
      idx_cash:Cash 索引
      abs_band, rel_band: 5/25 帶寬（大權重 >=20% 用絕對帶寬）
      tc_frac: 再平衡交易成本（每 1 元交易的成本比例，例如 10 bps = 0.001）
      rf_m:    月化無風險利率（Sharpe/Sortino 用）
      tau_m:   月化門檻（Omega 用）
    輸出： (多個 n_sims 向量)
      cagr, mdd, ulcer, tuw, maxdd_dur,
      sum_r, sum_r2, dn_sum_sq, dn_cnt, pos_exc, neg_exc
    """
    n_sims, M, d_nc = R_nc.shape
    YEARS = M / 12.0
    d_total = Wt_full.shape[0]

    cagr  = np.empty(n_sims, dtype=np.float64)
    mdd   = np.empty(n_sims, dtype=np.float64)
    ulcer = np.empty(n_sims, dtype=np.float64)
    tuw   = np.empty(n_sims, dtype=np.float64)
    maxdd_dur = np.empty(n_sims, dtype=np.float64)

    sum_r = np.empty(n_sims, dtype=np.float64)
    sum_r2 = np.empty(n_sims, dtype=np.float64)
    dn_sum_sq = np.empty(n_sims, dtype=np.float64)
    dn_cnt = np.empty(n_sims, dtype=np.float64)
    pos_exc = np.empty(n_sims, dtype=np.float64)
    neg_exc = np.empty(n_sims, dtype=np.float64)

    big_mask = np.zeros(d_total, dtype=np.uint8)
    for j in range(d_total):
        if Wt_full[j] >= 0.20:
            big_mask[j] = 1

    for s in prange(n_sims):
        w_full = np.zeros(d_total, dtype=np.float64)
        for j in range(d_total):
            w_full[j] = Wt_full[j]

        nav = 1.0
        peak = 1.0
        min_dd = 0.0
        months_under = 0.0
        sum_dd_sq = 0.0
        cur_dur = 0.0
        max_dur = 0.0

        sr = 0.0; sr2 = 0.0
        dsum = 0.0; dcnt = 0.0
        pexc = 0.0; nexc = 0.0

        for t in range(M):
            # 當月投組報酬（現金月報酬視為 0，若要時變可在 R_nc 擴增）
            r_p = 0.0
            for jnc in range(d_nc):
                j_full = idx_nc[jnc]
                r_p += w_full[j_full] * R_nc[s, t, jnc]

            nav *= (1.0 + r_p)
            if nav > peak:
                peak = nav; cur_dur = 0.0
            else:
                cur_dur += 1.0
                if cur_dur > max_dur: max_dur = cur_dur
            dd = nav / peak - 1.0
            if dd < min_dd: min_dd = dd
            if dd < 0.0:
                months_under += 1.0
                sum_dd_sq += dd * dd

            # 累積 return 統計（相對 rf/tau）
            sr += r_p; sr2 += r_p * r_p
            # Sortino：只計算低於 rf 的 downside
            if r_p < rf_m:
                diff = rf_m - r_p
                dsum += diff * diff
                dcnt += 1.0
            # Omega：以門檻 tau_m
            diff2 = r_p - tau_m
            if diff2 >= 0:
                pexc += diff2
            else:
                nexc += -diff2

            # 權重更新（含現金）
            denom = (1.0 + r_p)
            for jnc in range(d_nc):
                j_full = idx_nc[jnc]
                w_full[j_full] = w_full[j_full] * (1.0 + R_nc[s, t, jnc]) / denom
            w_full[idx_cash] = w_full[idx_cash] / denom

            # 年終帶寬檢查 + 再平衡
            if ((t+1) % 12) == 0:
                breach = False
                # 大權重：絕對 ±5pp
                for j in range(d_total):
                    if big_mask[j] == 1:
                        if abs(w_full[j] - Wt_full[j]) >= abs_band:
                            breach = True; break
                # 小權重：相對 ±25%
                if not breach:
                    for j in range(d_total):
                        if big_mask[j] == 0:
                            lo = Wt_full[j] * (1.0 - rel_band)
                            hi = Wt_full[j] * (1.0 + rel_band)
                            val = w_full[j]
                            if (val <= lo) or (val >= hi):
                                breach = True; break
                if breach:
                    # 交易成本：以總週轉（L1 距離的一半）估計
                    turnover = 0.0
                    for j in range(d_total):
                        turnover += abs(Wt_full[j] - w_full[j])
                    turnover *= 0.5
                    if tc_frac > 0.0:
                        nav *= (1.0 - tc_frac * turnover)
                    # 重設至目標
                    for j in range(d_total):
                        w_full[j] = Wt_full[j]

        cagr_s = nav**(1.0/YEARS) - 1.0
        cagr[s] = cagr_s
        mdd[s]  = min_dd
        ulcer[s] = math.sqrt(sum_dd_sq / months_under) if months_under > 0.0 else 0.0
        tuw[s] = months_under / M
        maxdd_dur[s] = max_dur

        sum_r[s] = sr; sum_r2[s] = sr2
        dn_sum_sq[s] = dsum; dn_cnt[s] = dcnt
        pos_exc[s] = pexc; neg_exc[s] = nexc

    return cagr, mdd, ulcer, tuw, maxdd_dur, sum_r, sum_r2, dn_sum_sq, dn_cnt, pos_exc, neg_exc

# ---------- Worker (頂層，避免 pickling) ----------

def batch_worker(args):
    (batch_idx, W_full, months, sims_this, seed, mp_pack, engine, eng_kwargs,
     idx_nc, idx_cash, abs_band, rel_band, tc_frac, rf_m, tau_m) = args
    mu, L, corr, vol, ret_full_nc = mp_pack
    # 準備路徑
    if engine == "normal":
        R_nc = simulate_monthly_returns_normal(sims_this, months, mu, L, seed).astype(np.float64)
    elif engine == "t":
        R_nc = simulate_monthly_returns_t(sims_this, months, mu, L, float(eng_kwargs.get("t_df",5.0)), seed).astype(np.float64)
    elif engine == "block_bootstrap":
        R_nc = simulate_monthly_returns_block_bootstrap(ret_full_nc, sims_this, months,
                                                        int(eng_kwargs.get("block_len",6)),
                                                        float(eng_kwargs.get("p_geom", 1.0/max(int(eng_kwargs.get("block_len",6)),1))),
                                                        seed).astype(np.float64)
    elif engine == "ewma":
        R_nc = simulate_engine("ewma", sims_this, months, 
                               type("D", (), {"mu_m":mu, "corr_m":corr, "vol_m":vol})(),
                               seed, ewma_lambda=float(eng_kwargs.get("ewma_lambda",0.94))).astype(np.float64)
    elif engine == "regime2":
        R_nc = simulate_monthly_returns_regime2(sims_this, months, ret_full_nc, seed, vol_q=float(eng_kwargs.get("vol_q",0.6))).astype(np.float64)
    else:
        raise ValueError("unknown engine")
    return (batch_idx,) + twr_numba_adv(W_full.astype(np.float64), R_nc, idx_nc, idx_cash, abs_band, rel_band, tc_frac, rf_m, tau_m)

def simulate_config_distribution(W_full: np.ndarray, mp: MarketParams, months: int, n_sims_total: int, batch_size: int,
                                 seed_base: int, abs_band: float, rel_band: float, engine: str,
                                 eng_kwargs: Dict[str, float], n_jobs: int,
                                 rf_annual: float, omega_threshold_annual: float, tc_bps: float):
    idx_nc  = np.array([mp.all_cols.index(c) for c in mp.noncash_cols], dtype=np.int64)
    idx_cash= np.int64(mp.all_cols.index("Cash"))
    n_batches = math.ceil(n_sims_total / batch_size)
    mp_pack = (mp.mu_m, mp.L_m, mp.corr_m, mp.vol_m, mp.ret_m_full[mp.noncash_cols].values.astype(np.float64))

    rf_m = (1.0 + rf_annual)**(1.0/12.0) - 1.0
    tau_m = (1.0 + omega_threshold_annual)**(1.0/12.0) - 1.0
    tc_frac = tc_bps * 1e-4

    args = []
    for b in range(n_batches):
        sims_this = batch_size if (b < n_batches-1) else (n_sims_total - batch_size*(n_batches-1))
        args.append((b, W_full, months, sims_this, seed_base + b, mp_pack, engine, eng_kwargs,
                     idx_nc, idx_cash, abs_band, rel_band, tc_frac, rf_m, tau_m))

    outs = []
    with ProcessPoolExecutor(max_workers=n_jobs) as ex:
        futs = {ex.submit(batch_worker, a): a[0] for a in args}
        total = len(futs)
        for j, fut in enumerate(as_completed(futs), 1):
            outs.append(fut.result())
            left = total - j; status("SIM", ERR.OK, f"批次 {j}/{total} 完成；剩 {left}")

    outs.sort(key=lambda x: x[0])
    # 拼接
    cat = lambda k: np.concatenate([o[k] for o in outs])  # k=1..11
    cagr, mdd, ulcer, tuw, maxdd_dur, sum_r, sum_r2, dn_sum_sq, dn_cnt, pos_exc, neg_exc = [cat(k) for k in range(1,12)]

    # 派生指標（年化波動/Sharpe/Sortino/Omega/Calmar）
    M = months
    mean_r = sum_r / M
    var_r  = np.maximum(sum_r2 / M - mean_r*mean_r, 0.0)
    vol_ann = np.sqrt(var_r) * np.sqrt(12.0)
    sharpe = np.where(vol_ann>0, (mean_r - rf_m) * np.sqrt(12.0) / np.sqrt(var_r), np.nan)
    dvar   = np.where(dn_cnt>0, dn_sum_sq / dn_cnt, 0.0)
    sortino = np.where(dvar>0, (mean_r - rf_m) * np.sqrt(12.0) / np.sqrt(dvar), np.nan)
    omega = np.where(neg_exc>0, pos_exc / neg_exc, np.inf)
    calmar = np.where(mdd<0, ( (1.0+mean_r)**12 - 1.0 ) / (-mdd), np.inf)  # 用年化平均替代 CAGR 近似

    extra = {"vol_ann":vol_ann, "sharpe":sharpe, "sortino":sortino, "omega":omega, "calmar":calmar, "maxdd_dur":maxdd_dur}
    return cagr, mdd, ulcer, tuw, extra

def cvar_from_distribution(x: np.ndarray, alpha: float = 0.05, lower_tail: bool = True) -> float:
    if x.size == 0: return float("nan")
    if lower_tail:
        q = np.quantile(x, alpha); return float(x[x <= q].mean())
    else:
        q = np.quantile(x, 1-alpha); return float(x[x >= q].mean())

# ---------- 粗篩、排序、繪圖 ----------

def gen_random_weights(n, all_cols, cash_max=0.20, constraints=None, seed=42):
    rng=np.random.default_rng(seed); d=len(all_cols); alpha=np.ones(d); alpha[all_cols.index("Cash")]=0.6
    res=[]; tries=0; MAX_TRIES=n*50
    while len(res)<n and tries<MAX_TRIES:
        w=rng.dirichlet(alpha); tries+=1
        if w[all_cols.index("Cash")]>cash_max+1e-12: continue
        bad=False
        if constraints:
            for k,(lo,hi) in constraints.items():
                if k in all_cols:
                    j=all_cols.index(k)
                    if not (lo-1e-12<=w[j]<=hi+1e-12): bad=True; break
        if bad: continue
        res.append(w.astype(np.float64))
    if len(res)<n: raise RuntimeError("insufficient weights")
    return np.vstack(res)

def pick_top_by_utopia(df, W_list, k=10):
    ret=df["CAGR_med"].to_numpy(); mdd=df["MDD_med"].to_numpy()
    rmin,rmax=ret.min(),ret.max(); dmin,dmax=mdd.min(),mdd.max()
    rnorm=(ret-rmin)/max(rmax-rmin,1e-12); dnorm=(mdd-dmin)/max(dmax-dmin,1e-12)
    dist2=(rnorm-1.0)**2 + (dnorm-1.0)**2
    ranked=df.copy(); ranked["score"]=dist2; ranked=ranked.sort_values("score").reset_index(drop=True)
    topk=ranked.head(k).copy(); topk["rank"]=np.arange(1,len(topk)+1)
    return topk, W_list[topk["idx"].to_numpy()]

def plot_scatter_frontier(df, out_png):
    plt.figure(figsize=(8,5))
    plt.scatter(-df["MDD_med"]*100, df["CAGR_med"]*100, s=8, alpha=0.4)
    plt.xlabel("中位 |MDD| (%)"); plt.ylabel("中位 CAGR (%)")
    plt.title("初步模擬（500次/組）效率雲"); plt.grid(True, alpha=0.3)
    plt.tight_layout(); plt.savefig(out_png, dpi=160); plt.close()

def plot_topk_bars(df, out_png):
    df=df.copy().sort_values("CAGR_med", ascending=False); labels=[f"#{i+1}" for i in range(len(df))]
    x=np.arange(len(df)); w=0.35
    plt.figure(figsize=(10,5.2))
    plt.bar(x-w/2, df["CAGR_med"]*100, width=w, label="CAGR(中位)")
    plt.bar(x+w/2, -df["MDD_med"]*100, width=w, label="|MDD|(中位)")
    plt.xticks(x, labels); plt.ylabel("%"); plt.title("TopK：CAGR(中位) vs |MDD|(中位)")
    plt.legend(); plt.grid(True, axis="y", alpha=0.3); plt.tight_layout(); plt.savefig(out_png, dpi=160); plt.close()

# ---------- OOS 走勢外驗證（歷史實績，不模擬）----------

def twr_path_from_real_returns(W_full: np.ndarray, R_nc: np.ndarray, abs_band: float, rel_band: float, tc_frac: float) -> Dict[str, float]:
    """對單一路徑（真實月報酬 path）計算指標；回傳 summary 字典"""
    idx_nc = np.arange(R_nc.shape[1], dtype=np.int64)
    idx_cash = R_nc.shape[1]  # 假設 Cash 月報酬=0
    # 構成 R_nc_full，使 numba 內核可重用
    R = R_nc.reshape(1, R_nc.shape[0], R_nc.shape[1])
    cagr, mdd, ulcer, tuw, maxdd_dur, sum_r, sum_r2, dn_sum_sq, dn_cnt, pos_exc, neg_exc = twr_numba_adv(
        Wt_full=W_full, R_nc=R, idx_nc=idx_nc, idx_cash=idx_cash,
        abs_band=abs_band, rel_band=rel_band, tc_frac=tc_frac, rf_m=0.0, tau_m=0.0
    )
    M = R_nc.shape[0]
    mean_r = sum_r[0] / M; var_r = max(sum_r2[0]/M - mean_r*mean_r, 0.0)
    vol_ann = math.sqrt(var_r) * math.sqrt(12.0)
    return {
        "CAGR": float(cagr[0]), "MDD": float(mdd[0]), "Ulcer": float(ulcer[0]), "TUW": float(tuw[0]),
        "MaxDD_Dur": float(maxdd_dur[0]), "Vol_ann": float(vol_ann)
    }

def walkforward_oos(ret_nc: pd.DataFrame, W_full: np.ndarray, train_m: int, test_m: int, step_m: int,
                    cov_shrink: str, cov_ridge: float, mean_shrink_alpha: float,
                    abs_band: float, rel_band: float, tc_bps: float) -> pd.DataFrame:
    """Rolling 窗口重新估參 → 用『真實』未來區間回測（非模擬）"""
    tc_frac = tc_bps * 1e-4
    rows = []
    T = len(ret_nc)
    for start in range(0, T - train_m - test_m + 1, step_m):
        train = ret_nc.iloc[start:start+train_m].values
        test  = ret_nc.iloc[start+train_m:start+train_m+test_m].values
        # 估參（僅為列示，實際 OOS 指標用 test 的真實 R）
        _ = shrink_cov_from_returns(train, method=cov_shrink, ridge=cov_ridge)
        # 指標
        summ = twr_path_from_real_returns(W_full, test, abs_band, rel_band, tc_frac)
        summ.update({"start": str(ret_nc.index[start].date()), "end": str(ret_nc.index[start+train_m+test_m-1].date())})
        rows.append(summ)
    return pd.DataFrame(rows)

# ---------- 主流程 ----------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", type=str, default="normalized_closing_prices.csv")
    ap.add_argument("--years", type=int, default=20)
    ap.add_argument("--coarse_sims", type=int, default=500)
    ap.add_argument("--detail_sims", type=int, default=20000)
    ap.add_argument("--detail_batch", type=int, default=2000)
    ap.add_argument("--weights", type=int, default=10000)
    ap.add_argument("--cash_max", type=float, default=0.20)
    ap.add_argument("--seed", type=int, default=1234)
    ap.add_argument("--abs_band", type=float, default=0.05)
    ap.add_argument("--rel_band", type=float, default=0.25)
    ap.add_argument("--tc_bps", type=float, default=0.0, help="再平衡交易成本（bps）")
    ap.add_argument("--rf_annual", type=float, default=0.0, help="Sharpe/Sortino 之 rf（年化）")
    ap.add_argument("--omega_thr_annual", type=float, default=0.0, help="Omega 門檻（年化）")
    ap.add_argument("--cash_annual", type=float, default=0.00)
    ap.add_argument("--engine", type=str, default="t", choices=["normal","t","block_bootstrap","ewma","regime2"])
    ap.add_argument("--t_df", type=float, default=5.0)
    ap.add_argument("--block_len", type=int, default=6)
    ap.add_argument("--p_geom", type=float, default=0.0, help="stationary bootstrap 幾何 p；0 表示自動=1/block_len")
    ap.add_argument("--ewma_lambda", type=float, default=0.94)
    ap.add_argument("--vol_q", type=float, default=0.6, help="regime2 分位閾值（越小越少高波月）")
    ap.add_argument("--cov_shrink", type=str, default="auto", choices=["auto","ridge","none"])
    ap.add_argument("--cov_ridge", type=float, default=0.10)
    ap.add_argument("--mean_shrink_alpha", type=float, default=0.0)
    ap.add_argument("--jobs", type=int, default=0)
    ap.add_argument("--crn", action="store_true", help="TopK 詳模擬共用共同亂數")
    # 外層參數不確定性 bootstrap
    ap.add_argument("--param_bootstrap_B", type=int, default=0, help=">0 啟用外層 bootstrap 次數")
    ap.add_argument("--param_block_len", type=int, default=12, help="外層 bootstrap 的期望區塊長")
    # OOS 走勢外驗證
    ap.add_argument("--oos_train_m", type=int, default=120)
    ap.add_argument("--oos_test_m", type=int, default=60)
    ap.add_argument("--oos_step_m", type=int, default=12)
    ap.add_argument("--oos_enable", action="store_true")
    args = ap.parse_args()

    MONTHS = args.years * 12
    n_jobs = args.jobs if args.jobs>0 else max(1,(os.cpu_count() or 1))
    cash_monthly_ret = (1.0 + args.cash_annual)**(1.0/12.0) - 1.0

    mp = load_and_estimate(args.csv, cash_return_monthly=cash_monthly_ret,
                           cov_shrink=args.cov_shrink, cov_ridge=args.cov_ridge,
                           mean_shrink_alpha=args.mean_shrink_alpha)

    # 產生隨機配置（粗篩）
    W_list = gen_random_weights(args.weights, mp.all_cols, cash_max=args.cash_max, constraints=None, seed=42)

    # ---- 粗篩（可使用共同亂數：每批同一條 R，僅種子不同） ----
    status("SIM-COARSE", ERR.OK, f"{len(W_list)} weights × {args.coarse_sims} sims | engine={args.engine}")
    rows = []
    idx_nc  = np.array([mp.all_cols.index(c) for c in mp.noncash_cols], dtype=np.int64)
    idx_cash= np.int64(mp.all_cols.index("Cash"))

    eng_kwargs = {"t_df":args.t_df, "block_len":args.block_len, "p_geom": (args.p_geom if args.p_geom>0 else 1.0/max(args.block_len,1)),
                  "ewma_lambda":args.ewma_lambda, "vol_q":args.vol_q}

    # 若 crn，則先生成一份 R_nc，全權重共用；否則各自生成
    if args.crn:
        R_nc_crn = simulate_engine(args.engine, args.coarse_sims, MONTHS, mp, seed=args.seed, 
                                   t_df=args.t_df, block_len=args.block_len, p_geom=(args.p_geom if args.p_geom>0 else None),
                                   ewma_lambda=args.ewma_lambda, vol_q=args.vol_q).astype(np.float64)

    for i, W in enumerate(W_list):
        if args.crn:
            c,m,u,t,_, sr, sr2, dss, dc, pe, ne = twr_numba_adv(W.astype(np.float64), R_nc_crn, idx_nc, idx_cash,
                                                                 args.abs_band, args.rel_band, args.tc_bps*1e-4, 0.0, 0.0)
            c_med = float(np.median(c)); m_med = float(np.median(m))
        else:
            R_nc = simulate_engine(args.engine, args.coarse_sims, MONTHS, mp, seed=args.seed+i, 
                                   t_df=args.t_df, block_len=args.block_len, p_geom=(args.p_geom if args.p_geom>0 else None),
                                   ewma_lambda=args.ewma_lambda, vol_q=args.vol_q).astype(np.float64)
            c,m,u,t,_, sr, sr2, dss, dc, pe, ne = twr_numba_adv(W.astype(np.float64), R_nc, idx_nc, idx_cash,
                                                                 args.abs_band, args.rel_band, args.tc_bps*1e-4, 0.0, 0.0)
            c_med = float(np.median(c)); m_med = float(np.median(m))
        rows.append((i, c_med, m_med))
        if (i+1) % 200 == 0 or (i+1)==len(W_list):
            status("SIM-COARSE", ERR.OK, f"progress {i+1}/{len(W_list)}")

    df_coarse = pd.DataFrame(rows, columns=["idx","CAGR_med","MDD_med"])
    plot_scatter_frontier(df_coarse, "coarse_frontier_upgraded.png")

    # ---- 選 Top10，進入詳模擬 ----
    top10_meta, W_top10 = pick_top_by_utopia(df_coarse, W_list, k=10)
    status("SIM-DETAIL", ERR.OK, f"Top10 × {args.detail_sims} sims (batch={args.detail_batch}) | engine={args.engine}")
    all_rows = []

    # 外層參數不確定性 bootstrap：B=0 表示關閉
    B = max(0, int(args.param_bootstrap_B))
    if B>0:
        rng = np.random.default_rng(args.seed+999)
        T = len(mp.ret_m_nc)
        p_geom_outer = 1.0 / max(args.param_block_len,1)

    for rank in range(W_top10.shape[0]):
        W = W_top10[rank]
        # 內層模擬（可混合外層）
        all_cagr=[]; all_mdd=[]; all_ulcer=[]; all_tuw=[]; all_vol=[]; all_sharpe=[]; all_sortino=[]; all_omega=[]; all_calmar=[]; all_maxdur=[]
        outer_rounds = (B if B>0 else 0)
        # 先做 baseline（不抽參數）
        cagr, mdd, ulcer, tuw, extra = simulate_config_distribution(W, mp, MONTHS, args.detail_sims, args.detail_batch,
                                                                    args.seed, args.abs_band, args.rel_band, args.engine, eng_kwargs, n_jobs,
                                                                    args.rf_annual, args.omega_thr_annual, args.tc_bps)
        all_cagr.append(cagr); all_mdd.append(mdd); all_ulcer.append(ulcer); all_tuw.append(tuw)
        all_vol.append(extra["vol_ann"]); all_sharpe.append(extra["sharpe"]); all_sortino.append(extra["sortino"])
        all_omega.append(extra["omega"]); all_calmar.append(extra["calmar"]); all_maxdur.append(extra["maxdd_dur"])

        # 外層參數不確定性抽樣
        for b in range(outer_rounds):
            # stationary bootstrap 重抽樣歷史月報酬以重估 μ/Σ
            idx = np.empty(T, dtype=np.int64); i= rng.integers(0,T)
            for t in range(T):
                idx[t]=i
                if rng.random()<p_geom_outer: i = rng.integers(0,T)
                else: i = (i+1)%T
            ret_nc_boot = mp.ret_m_nc.values[idx,:]
            # 重新估參
            mu = ret_nc_boot.mean(axis=0).astype(np.float64)
            mu = shrink_mean(mu, alpha=args.mean_shrink_alpha)
            Sigma_shrunk, corr, vol = shrink_cov_from_returns(ret_nc_boot, method=args.cov_shrink, ridge=args.cov_ridge)
            L = np.linalg.cholesky(Sigma_shrunk + 1e-10*np.eye(Sigma_shrunk.shape[0]))
            mp_boot = MarketParams(mu_m=mu, Sigma_m=Sigma_shrunk, L_m=L, corr_m=corr, vol_m=vol,
                                   noncash_cols=mp.noncash_cols, all_cols=mp.all_cols,
                                   ret_m_full=mp.ret_m_full, ret_m_nc=mp.ret_m_nc)
            cagr, mdd, ulcer, tuw, extra = simulate_config_distribution(W, mp_boot, MONTHS, args.detail_sims, args.detail_batch,
                                                                        args.seed+b+1, args.abs_band, args.rel_band, args.engine, eng_kwargs, n_jobs,
                                                                        args.rf_annual, args.omega_thr_annual, args.tc_bps)
            all_cagr.append(cagr); all_mdd.append(mdd); all_ulcer.append(ulcer); all_tuw.append(tuw)
            all_vol.append(extra["vol_ann"]); all_sharpe.append(extra["sharpe"]); all_sortino.append(extra["sortino"])
            all_omega.append(extra["omega"]); all_calmar.append(extra["calmar"]); all_maxdur.append(extra["maxdd_dur"])

        # 合併
        C = np.concatenate(all_cagr); D = np.concatenate(all_mdd); U = np.concatenate(all_ulcer); Tuw = np.concatenate(all_tuw)
        V = np.concatenate(all_vol); Sh = np.concatenate(all_sharpe); So = np.concatenate(all_sortino); Om = np.concatenate(all_omega); Ca = np.concatenate(all_calmar); Md = np.concatenate(all_maxdur)

        def P(a,q): return float(np.percentile(a,q))
        row = {
            "rank": rank+1,
            "SPY": W[mp.all_cols.index("SPY")] if "SPY" in mp.all_cols else 0.0,
            "QQQ": W[mp.all_cols.index("QQQ")] if "QQQ" in mp.all_cols else 0.0,
            "GLD": W[mp.all_cols.index("GLD")] if "GLD" in mp.all_cols else 0.0,
            "0050": W[mp.all_cols.index("0050")] if "0050" in mp.all_cols else 0.0,
            "Cash": W[mp.all_cols.index("Cash")],
            "CAGR_mean": float(np.mean(C)), "CAGR_med": float(np.median(C)),
            "CAGR_p05": P(C,5), "CAGR_p95": P(C,95),
            "MDD_mean": float(np.mean(D)),  "MDD_med": float(np.median(D)),
            "MDD_p05": P(D,5),  "MDD_p95": P(D,95),
            "Ulcer_med": float(np.median(U)), "TUW_med": float(np.median(Tuw)),
            "Vol_ann_med": float(np.median(V)),
            "Sharpe_med": float(np.nanmedian(Sh)), "Sortino_med": float(np.nanmedian(So)),
            "Omega_med": float(np.nanmedian(Om)),  "Calmar_med": float(np.nanmedian(Ca)),
            "MaxDD_Dur_med": float(np.median(Md)),
            "CAGR_CVaR5": cvar_from_distribution(C, 0.05, lower_tail=True),
            "MDD_CVaR5":  cvar_from_distribution(-D, 0.05, lower_tail=False)
        }
        all_rows.append(row)

        # Top3 分佈圖（沿用 baseline 結果）
        if rank < 3:
            def plot_distribution(arr, title, xlabel, out_png, bins=60):
                plt.figure(figsize=(8.5,5.0)); plt.hist(arr, bins=bins, density=True, alpha=0.8)
                plt.title(title); plt.xlabel(xlabel); plt.ylabel("密度"); plt.grid(True, alpha=0.3)
                plt.tight_layout(); plt.savefig(out_png, dpi=160); plt.close()
            plot_distribution(C*100, f"Top{rank+1} 年化報酬分佈（CAGR）", "年化報酬 (%)", f"top{rank+1}_cagr_distribution.png")
            plot_distribution(-D*100, f"Top{rank+1} 最大回撤分佈（|MDD|）", "最大回撤幅度 (%)", f"top{rank+1}_mdd_distribution.png")

    df_detail = pd.DataFrame(all_rows).sort_values("CAGR_med", ascending=False).reset_index(drop=True)
    df_detail.to_csv("top10_detail_summary.csv", index=False)
    plot_topk_bars(df_detail.head(10), "top10_bars_upgraded.png")

    best = df_detail.iloc[0]
    def pct(x): return f"{x*100:.2f}%"
    print("\n==== 最終分析（升級版）====")
    print("建議配置：", {c:f"{best[c]*100:.1f}%" for c in ["SPY","QQQ","GLD","0050","Cash"] if c in df_detail.columns})
    print(f"CAGR 中位 {pct(best['CAGR_med'])}，MDD 中位 {pct(best['MDD_med'])}，Ulcer(中位) {pct(best['Ulcer_med'])}，TUW(中位) {best['TUW_med']*100:.1f}%")
    print(f"Sharpe(中位) {best['Sharpe_med']:.2f}，Sortino(中位) {best['Sortino_med']:.2f}，Omega(中位) {best['Omega_med']:.2f}，Calmar(中位) {best['Calmar_med']:.2f}")
    print("輸出：coarse_frontier_upgraded.png、top10_bars_upgraded.png、Top1~Top3 分佈圖與 top10_detail_summary.csv")

    # ---- 走勢外驗證（可選）----
    if args.oos_enable:
        try:
            oos = walkforward_oos(mp.ret_m_nc, best[["SPY","QQQ","GLD","0050","Cash"]].reindex(mp.all_cols, fill_value=0.0).values,
                                  args.oos_train_m, args.oos_test_m, args.oos_step_m,
                                  args.cov_shrink, args.cov_ridge, args.mean_shrink_alpha,
                                  args.abs_band, args.rel_band, args.tc_bps)
            oos.to_csv("oos_walkforward_summary.csv", index=False)
            status("OOS", ERR.OK, f"已輸出 oos_walkforward_summary.csv")
        except Exception as e:
            status("OOS", ERR.OOS_FAIL, f"走勢外驗證失敗：{e}")

if __name__ == "__main__":
    main()
